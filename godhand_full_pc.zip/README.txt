GOD HAND - Native PC Build
==========================
Extract semua file ke satu folder, lalu double-click godhand_full.exe

Controls:
  Arrow Keys = Rotate model
  + / - = Zoom in/out
  SPACE = Toggle auto-rotate
  A = Toggle animation (wave motion)
  ESC = Quit

Requirements: Windows 10/11 (no Vulkan/DirectX needed!)
