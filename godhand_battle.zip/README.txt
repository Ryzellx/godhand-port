GOD HAND - Battle Scene (Native PC)
====================================
Extract ke satu folder, double-click godhand_battle.exe

Scene: Gene (protagonist) vs Enemy — 18.403 vertices dari disc asli!

Controls:
  Arrow Keys = Rotate camera
  + / - = Zoom
  SPACE = Auto-rotate
  A = Animation
  ESC = Quit

Data: Model 3D asli dari God Hand PS2 disc
